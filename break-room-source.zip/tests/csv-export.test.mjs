import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const source=readFileSync(new URL('../lib/csv-export.ts',import.meta.url),'utf8');
const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext}}).outputText;
const {csvCell,csvDocument,historyCsv}=await import('data:text/javascript;base64,'+Buffer.from(js).toString('base64'));
for(const prefix of ['=','+','-','@',' =','\t=','\r+','\n@','\u0000=','\t姓名']) {
 assert.equal(csvCell(prefix+'test'),'"\''+prefix+'test"');
}
assert.equal(csvCell('王"Blue",同學'),'"王""Blue"",同學"');
assert.equal(csvCell('第一行\n第二行'),'"第一行\n第二行"');
assert.equal(csvDocument([['中文','0'],['普通文字','']]),'\uFEFF"中文","0"\r\n"普通文字",""');
const history=[{time:'2026-10-05',kind:'wheel',text:' \t=1+1',audit:{rules:'一,二"三'}}];
const before=JSON.stringify(history);
assert.ok(historyCsv(history).includes('"\' \t=1+1"'));
assert.ok(historyCsv(history).includes('"規則與逐次紀錄"'));
assert.equal(JSON.stringify(history),before);
assert.equal(historyCsv([]).split('\r\n').length,1);
console.log('CSV regressions passed: prefixes, Unicode, quotes, multiline, headers, no mutation.');
