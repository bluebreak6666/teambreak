"use client";
import {useEffect,useRef,useState} from 'react';
import type {PairResult} from '@/lib/pair-export';

// Canvas text never interprets participant input as HTML or spreadsheet formulas.
export function wrapText(ctx:CanvasRenderingContext2D,text:string,width:number){
 const lines:string[]=[];let line='';
 for(const char of Array.from(text)){if(char==='\n'){lines.push(line);line='';continue}if(line&&ctx.measureText(line+char).width>width){lines.push(line);line=char}else line+=char}
 lines.push(line);return lines;
}
export async function renderPoster(result:PairResult,page:number){
 await document.fonts.ready;
 const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');
 if(!ctx)throw Error('瀏覽器無法產生圖片');
 const rows=result.rows.slice(page*20,(page+1)*20),pages=Math.ceil(result.rows.length/20);
 const font='"Noto Sans TC", "Microsoft JhengHei", Arial, sans-serif';
 ctx.font=`600 32px ${font}`;
 const titleLines=wrapText(ctx,result.title,900);
 ctx.font=`500 29px ${font}`;
 const content=rows.map(row=>wrapText(ctx,row,810));
 const header=230+titleLines.length*46;
 const heights=content.map(lines=>Math.max(76,lines.length*42+32));
 const height=header+heights.reduce((a,b)=>a+b,0)+130;
 if(height>16000)throw Error('名單文字過長，請縮短個別名稱後重新產生結果。');
 canvas.width=1080;canvas.height=height;
 ctx.fillStyle='#101b19';ctx.fillRect(0,0,1080,height);
 ctx.fillStyle='#c8f45b';ctx.fillRect(0,0,1080,12);
 ctx.font=`700 24px ${font}`;ctx.fillText('BREAK ROOM / 分隊結果',64,78);
 ctx.fillStyle='#f3f4ec';ctx.font=`600 40px ${font}`;
 // Use the same font for measurement and drawing so long titles never overflow.
 ctx.font=`600 32px ${font}`;titleLines.forEach((line,i)=>ctx.fillText(line,64,140+i*46));
 const infoY=164+titleLines.length*46;
 ctx.fillStyle='#b5c6ba';ctx.font=`400 21px ${font}`;
 ctx.fillText(new Date(result.createdAt).toLocaleString('zh-TW',{timeZone:'Asia/Taipei',hour12:false})+' 台灣時間',64,infoY);
 ctx.fillText(`${result.linked?'人名配對':'獨立排序'} · ${result.rows.length} 個名額 · 第 ${page+1} / ${pages} 張`,64,infoY+36);
 let y=header;
 content.forEach((lines,i)=>{ctx.fillStyle=i%2?'#21312b':'#1a2823';ctx.fillRect(48,y,984,heights[i]-8);ctx.fillStyle='#c8f45b';ctx.font=`700 23px ${font}`;ctx.fillText(String(page*20+i+1).padStart(2,'0'),72,y+46);ctx.fillStyle='#f2f5ee';ctx.font=`500 29px ${font}`;lines.forEach((line,j)=>ctx.fillText(line,150,y+46+j*42));y+=heights[i]});
 ctx.fillStyle='#96ac9f';ctx.font=`400 20px ${font}`;ctx.fillText('GOOD LUCK, COLLECTORS.',64,height-62);
 ctx.fillText('分隊完成時的結果快照',64,height-30);
 return new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('圖片產生失敗')),'image/png'));
}
export default function PairPoster({result}:{result:PairResult}){
 const [url,setUrl]=useState(''),[page,setPage]=useState(0),[open,setOpen]=useState(false),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const generation=useRef(0);const pages=Math.ceil(result.rows.length/20);
 useEffect(()=>{setPage(0);setOpen(false);setUrl('');setError('')},[result]);
 useEffect(()=>{if(!open)return;const id=++generation.current;let current='';setBusy(true);setError('');setUrl('');renderPoster(result,page).then(blob=>{if(id===generation.current){current=URL.createObjectURL(blob);setUrl(current)}}).catch(e=>{if(id===generation.current)setError(e.message)}).finally(()=>{if(id===generation.current)setBusy(false)});return()=>{generation.current++;if(current)URL.revokeObjectURL(current)}},[result,page,open]);
 return <div><button className="outline" onClick={()=>setOpen(o=>!o)}>{open?'收起分享清單':'製作分享清單 PNG'}</button>{open&&<section className="poster-preview" aria-label="分隊分享清單"><div className="poster-controls">{pages>1&&<><button disabled={page===0} onClick={()=>setPage(p=>p-1)}>上一張</button><span>{page+1} / {pages}</span><button disabled={page===pages-1} onClick={()=>setPage(p=>p+1)}>下一張</button></>}{url&&!busy&&<a className="outline" href={url} download={`BREAK-ROOM-${result.createdAt.slice(0,10)}-${page+1}.png`}>下載第 {page+1} 張 PNG ↓</a>}</div>{busy&&<p role="status">正在製作分享圖…</p>}{error&&<p role="alert" className="poster-error">{error}</p>}{url&&!busy&&<img src={url} alt={`分隊結果分享圖，第 ${page+1} 張`}/>}<p>每張最多 20 個名額；分享前請確認參加者姓名可公開。圖片沿用已完成結果，不會重新抽選。</p></section>}</div>
}
