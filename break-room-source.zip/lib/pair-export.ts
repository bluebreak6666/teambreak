import {csvDocument} from './csv-export';
export type PairResult={rows:string[];createdAt:string;title:string;linked:boolean};
export function isPairResult(value:unknown):value is PairResult{
 const v=value as PairResult;return !!v&&Array.isArray(v.rows)&&v.rows.length>0&&v.rows.length<=100&&v.rows.every(r=>typeof r==='string'&&r.length<=4000)&&typeof v.title==='string'&&v.title.length<=200&&typeof v.createdAt==='string'&&Number.isFinite(Date.parse(v.createdAt))&&typeof v.linked==='boolean';
}
export function pairCsv(result:PairResult){
 return csvDocument([['場次標題','產生時間','模式','順序','結果'],...result.rows.map((r,i)=>[result.title,result.createdAt,result.linked?'人名配對':'獨立排序',String(i+1),r])]);
}
