export type FillMode = 'none' | 'blank' | 'value';
export function preparePairing(items:string[],names:string[],mode:FillMode,value:string){
 const size=Math.max(items.length,names.length);
 if(size<1||size>100)throw Error('配對需有 1–100 個名額');
 if(items.length===names.length)return {items:[...items],names:[...names],added:0,side:''};
 if(mode==='none')throw Error('數量尚未吻合，請選擇補空白或填入指定值');
 const fill=mode==='blank'?'':value.trim();
 if(mode==='value'&&(!fill||fill.length>80||/[\r\n]/.test(fill)))throw Error('請輸入 1–80 字的單一值，例如 0、未售出或保留');
 const side=names.length<items.length?'參加名單':'項目清單';
 const pad=(list:string[])=>[...list,...Array<string>(size-list.length).fill(fill)];
 return {items:pad(items),names:pad(names),added:Math.abs(items.length-names.length),side};
}
