/** Quote every field and neutralize formula-like prefixes, including leading whitespace. */
export function csvCell(value:string):string {
 const unsafe=/^[\s\u0000-\u001f]*[=+@-]/.test(value)||/^[\t\r\n]/.test(value);
 return '"'+(unsafe?"'":'')+value.replaceAll('"','""')+'"';
}
export function csvDocument(rows:string[][]):string {
 return '\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n');
}
export function historyCsv(history:ReadonlyArray<{time:string;kind:string;text:string;audit?:unknown}>):string {
 return csvDocument([['時間','模式','結果','規則與逐次紀錄'],...history.map(h=>[h.time,h.kind,h.text,h.audit?JSON.stringify(h.audit):''])]);
}
